package com.main;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int dividend = 3;
		int divisor = 2;

		double result = dividend / divisor * 1.0;
		System.out.println(result);

	}

}
